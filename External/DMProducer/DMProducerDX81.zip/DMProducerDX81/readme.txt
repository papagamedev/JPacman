DirectMusic Producer DirectX 8.1

DirectMusic is a DirectX technology.  Designed to provide an extensible music
solution for DirectX platforms, DirectMusic provides a large palette of tools
for creating high quality interactive and non-repetitive music and audio content.
By providing a framework for musical interactivity, DirectMusic lets you build
musical intelligence into multimedia titles for Windows. 

Late breaking KNOWN ISSUE for DirectX 8.1: Switching to Super Low Latency then 
triggering a script that plays a segment with a custom audiopath will cause 
Producer to crash.  The workaround is to hit the 'refresh' button in Script 
Designer before triggering the routine.  Also note that this is not an issue if 
Super Low Latency is already checked when you start Producer.

DirectMusic introduces technologies and file formats that have previously not
been available.  To allow composers to integrate the resources of DirectMusic 
with the consistent sound performance of DLS, an authoring tool is included in 
this SDK.  This authoring tool is DirectMusic Producer. 

Within Producer, individual file objects, such as waves, MIDI files, styles, 
chordmaps, segments, and DLS files, are supported by integrated editor modules 
that know how to communicate with each other and work synchronously with real 
time interactive editing on top of the DirectMusic engine.

DirectMusic Producer consists of the following elements:
a. Framework: the environment which hosts all authoring components;
b. The Conductor component: acts as the liaison between authoring components
   and the DirectMusic engine;
c. Style Designer component: provides for creation of interactive music files;
d. Chordmap Designer component: variable chords and scales;
e. Band Editor component: assigning instrument settings (patch changes)
   including DLS;
f. Segment Designer component: allows for open ended creation of different track
   types to be integrated into musical compositions.  MIDI, wave and style 
   files can be used together or independently.
h. DLS Designer component: for creation of Downloadable Sounds soundsets for 
   both DLS1 and DLS2 format.
e. A new Script Designer: allows the composer or sound designer to use a basic 
   scripting language to control the behavior of content playback.  Detailed 
   information can be found in the DirectMusic Producer Help file under the 
   topic 'Script Designer'.
f. A new Audiopath Designer: providing the user with the ability to create mix groups,
   route mix groups to specific ports, and to set up real-time software effects via 
   DirectX Media Objects (DMO's).  

The Producer setup will automatically uninstall any existing versions of
Producer found on your machine. It is recommended that you close Producer
before attempting to install. 

The DirectX 8.1 version of Producer defaults to a different folder than previous
versions, so if you have a shortcut pointing to the old location that shortcut
will no longer work. 

Producer requires either Windows XP or the DirectX8.1 version of DirectMusic, as 
Producer functionality is built entirely on top of DirectMusic. (The Producer 
installation process will prompt to install the correct runtime bits, if they are not 
already present.)  

DirectMusic Producer also requires IE6.0 (or higher). 

The Help documentation includes a basic tutorial as well as a brand new advanced
tutorial to introduce some DirectMusic concepts.  An additional project of sample 
content can be found on the SDK CD at "\dxf\dxsdk\essentls\dmusprod\democontent\
dmpdemocontent.exe". Note that this sample content has not changed since DX8.0 so if 
you have already previously installed it there is no need to reinstall. The project 
will install to "My Documents\DMUSProducer\Demo8\" on your hard drive.

For more detailed and up-to-date information on DirectMusic Producer, please
read dmusprod.txt after installing DirectMusic Producer.